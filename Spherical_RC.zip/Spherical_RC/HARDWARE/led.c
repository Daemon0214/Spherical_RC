#include "led.h"
#include "CHARGER.h"
#include "delay.h"

void LED_Init(void)
{
 
 GPIO_InitTypeDef  GPIO_InitStructure;
 	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PB,PE�˿�ʱ��
	
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12;				 //LED0-->PB.5 �˿�����
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOA, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOB.5
 GPIO_SetBits(GPIOA,GPIO_Pin_12);						 //PB.5 �����
 GPIO_SetBits(GPIOA,GPIO_Pin_11);						 //PB.5 �����

 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;	    		 //LED1-->PE.5 �˿�����, �������
 GPIO_Init(GPIOB, &GPIO_InitStructure);	  				 //������� ��IO���ٶ�Ϊ50MHz
 GPIO_SetBits(GPIOB,GPIO_Pin_12); 						 //PE.5 �����
 GPIO_SetBits(GPIOB,GPIO_Pin_13); 						 //PE.5 �����
 GPIO_SetBits(GPIOB,GPIO_Pin_14); 						 //PE.5 �����
 GPIO_SetBits(GPIOB,GPIO_Pin_15); 						 //PE.5 �����
}

void LED_Disp(void){
	
	LED1 = 0;
	LED2 = 0;
	LED3 = 0;
	LED4 = 0;
	
//	if(Prcent_CHG==0){
//		LED1 = 1;
//		LED2 = 1;
//		LED3 = 1;
//		LED4 = 1;
//	}
//	else if((Prcent_CHG>0)&&(Prcent_CHG<=0.25)){
//		LED1 = 0;
//		LED2 = 1;
//		LED3 = 1;
//		LED4 = 1;
//	}
//	else if((Prcent_CHG>0.25)&&(Prcent_CHG<=0.50)){
//		LED1 = 0;
//		LED2 = 0;
//		LED3 = 1;
//		LED4 = 1;
//	}
//	else if((Prcent_CHG>0.50)&&(Prcent_CHG<=0.75)){
//		LED1 = 0;
//		LED2 = 0;
//		LED3 = 0;
//		LED4 = 1;
//	}
//	else if((Prcent_CHG>0.75)&&(Prcent_CHG<=1.00)){
//		LED1 = 0;
//		LED2 = 0;
//		LED3 = 0;
//		LED4 = 0;
//	}
//	else{
//		
//	}

}

void Sys_On_Led_Disp(void){
		LEDG = 1;
		LED1 = 1;
		LED2 = 1;
		LED3 = 1;
		LED4 = 1;
		delay_ms(800);
		LEDG = 1;
		LED1 = 0;
		LED2 = 1;
		LED3 = 1;
		LED4 = 1;
		delay_ms(800);
		LEDG = 1;
		LED1 = 0;
		LED2 = 0;
		LED3 = 1;
		LED4 = 1;
		delay_ms(800);
		LEDG = 1;
		LED1 = 0;
		LED2 = 0;
		LED3 = 0;
		LED4 = 1;
		delay_ms(800);
		LEDG = 1;
		LED1 = 0;
		LED2 = 0;
		LED3 = 0;
		LED4 = 0;
		delay_ms(800);
		LEDG = 0;
		LED1 = 0;
		LED2 = 0;
		LED3 = 0;
		LED4 = 0;
		delay_ms(800);
}
