#ifndef __CHARGER_H
#define __CHARGER_H

#include "sys.h"

extern u16 Charger;
extern float Prcent_CHG;

void Charger_Init(void);
void Charger_Proc(void);

#endif
