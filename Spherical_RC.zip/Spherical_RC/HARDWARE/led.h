#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LEDG PAout(11)	// PA8
#define LEDB PAout(12)	// PA8
#define LED1 PBout(12)	// PD2
#define LED2 PBout(13)	// PD2
#define LED3 PBout(14)	// PD2
#define LED4 PBout(15)	// PD2

void LED_Init(void);//��ʼ��
void LED_Disp(void);
void Sys_On_Led_Disp(void);

		 				    
#endif
