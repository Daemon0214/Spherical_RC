#ifndef __DAC_H
#define __DAC_H

#include "sys.h"

void Dac1_Init(void);

#endif
