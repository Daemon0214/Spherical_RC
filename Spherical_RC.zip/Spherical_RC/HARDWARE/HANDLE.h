#ifndef __HANDLE_H
#define __HANDLE_H

#include "sys.h"

extern u16 Handle_LX;
extern u16 Handle_LY;
extern u16 Handle_RX;
extern u16 Handle_RY;
extern float Prcent_LX;
extern float Prcent_LY;
extern float Prcent_RX;
extern float Prcent_RY;
extern s16 Send_HLX;
extern s16 Send_HRY;

void Handle_Init(void);
void Handle_Proc(void);

#endif
