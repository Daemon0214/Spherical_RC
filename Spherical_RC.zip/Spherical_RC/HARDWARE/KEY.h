#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x.h"

#define PWR_OFF  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)
#define Key1     GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0)
#define Key2     GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)
#define Key3     GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)
#define Key4     GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)
#define Key5     GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_9)
#define Key6     GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_8)

extern u16 Key_Value1;
extern u16 Key_Value2;
extern u16 Key_Value3;
extern u16 Key_Value4;
extern u16 Key_Value5;
extern u16 Key_Value6;
extern u16 CTL_MODE;
extern float pitch,roll,yaw;
extern u8 SYS_IS_ON;

typedef enum
{
    KEY_CHECK = 0,
    KEY_COMFIRM = 1,
    KEY_RELEASE = 2
}KEY_STATE;

typedef enum 
{
    NULL_KEY = 0,
    SHORT_KEY =1,
    LONG_KEY
}KEY_TYPE;

extern KEY_STATE KeyStateP;
extern KEY_TYPE g_KeyActionFlagP;
extern KEY_STATE KeyState1;
extern KEY_TYPE g_KeyActionFlag1;
extern KEY_STATE KeyState2;
extern KEY_TYPE g_KeyActionFlag2;
extern KEY_STATE KeyState3;
extern KEY_TYPE g_KeyActionFlag3;
extern KEY_STATE KeyState4;
extern KEY_TYPE g_KeyActionFlag4;
extern KEY_STATE KeyState5;
extern KEY_TYPE g_KeyActionFlag5;
extern KEY_STATE KeyState6;
extern KEY_TYPE g_KeyActionFlag6;

//��������ʵ�ֳ����Ͷ̰�
#define SingleKey_LongShort_Event	1
void Key_Init(void);
void Key_Scan(void);
void Key_Proc(void);

#endif
