/**
  ******************************************************************************
  * @file    GPIO/IOToggle/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "KEY.h"
#include "usart.h"
#include "HANDLE.h"
#include "led.h"
#include "I2C.h"
#include "I2C_MPU6050.h"
#include "MPU6050.h"
#include "PWR.h"

u8 Key_Count = 0;
u8 Uart_Count = 0;
u8 Test_Count = 0;
u8 Led_Count = 0;
u8 IMU_Count = 0;
u16 BUTTON_LONG_PRESS_DELAY = 0;
 
void NMI_Handler(void)
{
}
 
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}
 
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

 
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}
 
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}
 
void SVC_Handler(void)
{
}
 
void DebugMon_Handler(void)
{
}
 
void PendSV_Handler(void)
{
}
 
void SysTick_Handler(void)
{
	if((SYS_IS_ON == 2)||(SYS_IS_ON == 3)||(SYS_IS_ON == 4)){
		
			if(SYS_IS_ON == 3){
				BUTTON_LONG_PRESS_DELAY++;
				if(BUTTON_LONG_PRESS_DELAY >= 1000){
					SYS_IS_ON = 2;
					BUTTON_LONG_PRESS_DELAY = 0;
				}
			}
			
			Key_Count++;
			Uart_Count++;
			Led_Count++;
			IMU_Count++;
			
			if(Key_Count >= 2){
				Key_Scan();
				Key_Proc();
				Key_Count = 0;
			}
			
			if(Led_Count >= 200){
				LED_Disp();
				Led_Count = 0;
			}
			
			if(IMU_Count>=10){
				MPU6050_Pose();
				IMU_Count = 0;
			}
			
			if(Uart_Count >= 100){
				Uart4_Report((s16)Key_Value1,(s16)Key_Value2,(s16)Key_Value3,(s16)Key_Value4,(s16)Key_Value5,(s16)Key_Value6,(s16)Send_HRY,(s16)Send_HLX);
				UART4_Send_Byte(0X0D);
				UART4_Send_Byte(0X0A);
				Uart_Count = 0;
			}
		}
	
}

