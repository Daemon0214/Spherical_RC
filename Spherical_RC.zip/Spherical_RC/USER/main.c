#include "stm32f10x.h"
#include "stm32f10x_it.h"
#include "delay.h"
#include "usart.h"
#include "Systick.h"
#include "PWR.h"
#include "Audio.h"
#include "CHARGER.h"
#include "HANDLE.h"
#include "KEY.h"
#include "MOT.h"
#include "lcd.h"
#include "lcd_init.h"
#include "led.h"
#include "I2C.h"
#include "I2C_MPU6050.h"
#include "MPU6050.h"
#include "DAC.h"
#include "Timer.h"

u32 t = 0;

int main(void)
{
	Power_Init(); //��Դ��ʼ��
	Power_On(); //��������
	delay_init();	    	 //��ʱ������ʼ��
	SysTick_Init();						  //SysTick������ʼ��	
	SysTick->CTRL |=  SysTick_CTRL_ENABLE_Msk;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
	LED_Init();//Led��ʼ��
	Charger_Init(); //�����Ƴ�ʼ��
	Key_Init();//������ʼ��
	Charger_Proc();

	
	while(1)
	{
		if(SYS_IS_ON == 0){
			LEDG = 1;
			t++;
			Key_Scan();
			delay_ms(50);
			Key_Proc();
			LED_Disp();
			if(t >= 500){
				Power_Off();//�ػ�
			}
		}
		
		if(SYS_IS_ON == 1){
			Sys_On_Led_Disp();
			LEDG = 0;
			TFT_Power_On();//TFT��Դ��
			Motor_Init(); //�������ʼ��
			Handle_Init(); //ҡ�˳�ʼ��
			USART1_Config();  //USART1��ʼ��
			UART4_Config();
			TIM3_Int_Init(71,155); //��Ƶ�жϳ�ʼ��
			Dac1_Init();//��ƵDAC��ʼ��
			Music_Flag = 0;
			MOT1 =MOT2 = 1;
			delay_ms(500);
				if(Music_Flag == 0){
						TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
						TIM_Cmd(TIM3, ENABLE);
						DAC_Cmd(DAC_Channel_1, ENABLE);
					}
			MOT1 = MOT2 = 0;
			i2cInit();							   //IIC��ʼ�� ���ڹҿ��������ϵ��豸ʹ��
			delay_ms(10);						   //��ʱ10ms
			MPU6050_Init();						   //MPU6050 DMP�����ǳ�ʼ��
			LCD_Init();//LCD��ʼ��
			LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
			LCD_ShowString(5,0,"CHG:",BLACK,WHITE,16,0);
			LCD_ShowString(5,20,"CMDX:",BLACK,WHITE,16,0);
			LCD_ShowString(5,40,"CMDY:",BLACK,WHITE,16,0);
			LCD_ShowString(5,60,"MODE:",BLACK,WHITE,16,0);
			LCD_ShowString(5,80,"SEDY:",BLACK,WHITE,16,0);
			LCD_ShowString(5,100,"SEDX:",BLACK,WHITE,16,0);

			SYS_IS_ON = 2;
		}
		
		if((SYS_IS_ON == 2)||(SYS_IS_ON == 3)||(SYS_IS_ON == 4)){
			Handle_Proc();
			Charger_Proc();
			
			if(SYS_IS_ON != 4){
			LCD_ShowIntNum(40,0,(u16)(Prcent_CHG*100),3,RED, WHITE, 16);
			LCD_ShowString(76,0,"%",RED,WHITE,16,0);
			
			if(CTL_MODE == 0){
					Send_HLX = Handle_LX;
					Send_HRY = Handle_RY;
				
					if(Prcent_LX<=0.4){
						LCD_ShowString(45,20,"LEFT ",RED,WHITE,16,0);
					}
					else if(Prcent_LX>=0.6){
						LCD_ShowString(45,20,"RIGHT",RED,WHITE,16,0);
					}
					else{
						LCD_ShowString(45,20,"STOP ",RED,WHITE,16,0);
					}
					
					if(Prcent_RY<=0.4){
						LCD_ShowString(45,40,"BACK   ",RED,WHITE,16,0);
					}
					else if(Prcent_RY>=0.6){
						LCD_ShowString(45,40,"FORWARD",RED,WHITE,16,0);
					}
					else{
						LCD_ShowString(45,40,"STOP   ",RED,WHITE,16,0);
					}
			}
			
			else{
					if((Roll<=165)&&(Roll>=120)){
						LCD_ShowString(45,20,"LEFT ",RED,WHITE,16,0);
						Send_HLX = 500;
					}
					else if((Roll<=-120)&&(Roll>=-165)){
						LCD_ShowString(45,20,"RIGHT",RED,WHITE,16,0);
						Send_HLX = 3100;
					}
					else{
						LCD_ShowString(45,20,"STOP ",RED,WHITE,16,0);
						Send_HLX = 2000;
					}
					
					if((Pitch<=-15)&&(Pitch>=-90)){
						LCD_ShowString(45,40,"BACK   ",RED,WHITE,16,0);
						Send_HRY = 500;
					}
					else if((Pitch<=90)&&(Pitch>=15)){
						LCD_ShowString(45,40,"FORWARD",RED,WHITE,16,0);
						Send_HRY = 3100;
					}
					else{
						LCD_ShowString(45,40,"STOP   ",RED,WHITE,16,0);
						Send_HRY = 2000;
					}
			}
			LCD_ShowIntNum(50,80,(u16)(Send_HRY),5,RED, WHITE, 16);
			LCD_ShowIntNum(50,100,(u16)(Send_HLX),5,RED, WHITE, 16);
			
			
			if(CTL_MODE == 0){
				LCD_ShowString(45,60,"HANDLE",RED,WHITE,16,0);
			}
			else{
				LCD_ShowString(45,60,"IMU   ",RED,WHITE,16,0);
			}
		

		}
	}

	}
}

